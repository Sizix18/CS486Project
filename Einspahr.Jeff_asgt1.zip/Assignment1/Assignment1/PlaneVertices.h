//
//  PlaneVertices.h
//  Assignment1
//
//  Created by Jeff Einspahr on 11/26/13.
//  Copyright (c) 2013 Jeff Einspahr. All rights reserved.
//

#ifndef Assignment1_PlaneVertices_h
#define Assignment1_PlaneVertices_h
#include "VertexDataPosn.h"

VertexDataPosn PlaneVertices [] = {
    -10.0, -1.0, -10.0,
    -10.0, -1.0,  10.0,
    10.0, -1.0,  10.0,
    10.0, -1.0, -10.0,
};

#endif
