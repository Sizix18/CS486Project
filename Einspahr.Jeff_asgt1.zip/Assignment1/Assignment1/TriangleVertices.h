//
//  TriangleVertices.h
//  Assignment1
//
//  Created by Jeff Einspahr on 11/24/13.
//  Copyright (c) 2013 Jeff Einspahr. All rights reserved.
//

#ifndef Assignment1_TriangleVertices_h
#define Assignment1_TriangleVertices_h

#include "VertexDataPosn.h"

VertexDataPosn vertices[] = {
    -0.5f, -0.5f, 0.0f,
    0.5f, -0.5f, 0.0f,
    0.0f, 0.5f, 0.0f,
};


#endif
