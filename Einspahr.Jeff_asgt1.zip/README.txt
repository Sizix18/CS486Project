Jeff Einspahr
jeffeinspahr@csu.fullerton.edu
The assignment was to implement a skybox, ply models, picking, quaternions, and a scene graph in an openGL project using vertex buffer objects.

This assignment was completed with heavy help from a tutorial series by a youtube user that goes by the name of Initwithdata, which covered openGL 3.3+ and GLFW3.
His github username is dimi814

Implemented Items:
Vertex buffer objects, of multiple shapes including a skybox, pyramid, cube and plane.
GLSL vertex and fragment Shaders
keyboard controls including forward, backward arrows, and q.
While not in a scene graph, each object in the scene, is in a vector.

Unimplemented Items:
-v for verbose mode
-h for help 
mouse controls
picking
rotation around an arbritrary axis
Ply models

